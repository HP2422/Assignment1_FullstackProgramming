var uModel = require('../model/model');
var allData = require('../model/g2pagemodel');

// create and save new data
exports.create = (req, res) => {

}


// retrive and return all data
exports.find = (req, res) => {

}


// update a new data 
exports.update = (req, res) => {

}

// delete a user with specified user

exports.delete = (req, res) => {

}